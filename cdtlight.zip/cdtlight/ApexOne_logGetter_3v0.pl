$::help=<<EOHelp;
$0 [-h] [-v]

ProgramId : "ApexOne_logGetter"
Version : "3.0"

-h	:  Help, this text.
-v      :  Verbose mode.  Allows the user to see a summary of the activity being performed.

The program collects operating system information and OfficeScan client and server
related log files and configuration files.  What we collect:
* SystemInfo.nfo
* Application.evtx
* System.evtx
* Registry entries related to OfficeScan client and server
* OfficeScan configuration files
* existing OfficeScan log files.
Version 2.1
* Add collection of last 10 IIS log files
* Collecting .db files containing client malware logs
* Expanded files checked for versioning.
Version 3.0
* Add collection of .log and .db files for iProducts

At no time do we modify any regitry keys to enable or disable any services. This
program is collecting existing information only.  For more detailed log collection
please use our CaseDiagnosticTool; http://downloadcenter.trendmicro.com
EOHelp


MAIN: 
{

require "geen_lib.pm";
use warnings;
use Encode::Guess;	#needed to guess encoding type.
use File::Copy;		#needed for simplfied file copy.
use Win32::Exe qw( );		#needed to get file information
use Data::Dumper qw( Dumper );	#needed to parse ASCII text from the info gather in Win32::Exe

#get number of seconds since the EPOCH
my $secEPOCH = time();
my $lastweek = $secEPOCH - (86400*7);
my $verbose = 0;

#Convert EPOCH and last week to something a little more readable.
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($secEPOCH);
my ($ysec,$ymin,$yhour,$ymday,$ymon,$yyear,$ywday,$yyday,$yisdst) = localtime($lastweek);

$year+=1900;
$mon+=1;
$mon=&zero_pad($mon);
$mday=&zero_pad($mday);
$hour=&zero_pad($hour);
$min=&zero_pad($min);
$sec=&zero_pad($sec);


$yyear+=1900;
$ymon+=1;
$ymon=&zero_pad($ymon);
$ymday=&zero_pad($ymday);
$yhour=&zero_pad($yhour);
$ymin=&zero_pad($ymin);
$ysec=&zero_pad($ysec);

my $dtstring=$year.$mon.$mday."T".$hour.$min.$sec;
my ($programfiles, $progfilesx86, $nobit64, $sysroot, $sysdrive, $windir, $tempdir, $computername, $fnprefix)=("","",0,"","","","","","");
my $IISLogDir="C:\\inetpub\\logs\\LogFiles\\W3SVC3";

while (@ARGV)
	{
	my $element = shift(@ARGV);
	SWITCH:
		{
		if ($element eq "-h") { print "$::help"; exit 0; }
		if ($element eq "-v") { $verbose=1; last; }
		print "$::help"; exit 1; 
		}	#end SWITCH tree.
	}	#end while @ARGV is still populated.

########################################################################
#Get environment variables
########################################################################
print "Getting a few environment variables...\n" if $verbose;
$programfiles="$ENV{ProgramFiles}";
if ( $ENV{'ProgramFiles(x86)'} ) 
    { $progfilesx86="$ENV{'ProgramFiles(x86)'}"; 
    $nobit64=1; 
    }
else { $nobit64=0; }
$sysroot="$ENV{SystemRoot}"; 
$sysdrive="$ENV{SystemDrive}";
$windir="$ENV{windir}";
$tempdir="$ENV{TEMP}";
$computername="$ENV{COMPUTERNAME}";

########################################################################
# Create a file name prefis with the comptuer name and date/time string.
########################################################################
$fnprefix=$computername."_".$dtstring;

########################################################################
#create directory structure to hold collected data
########################################################################
mkdir $fnprefix;
mkdir "$fnprefix/server";
mkdir "$fnprefix/Edgesvr";
mkdir "$fnprefix/server/IISLogs";
mkdir "$fnprefix/client";
chdir $fnprefix;

########################################################################
#Get system information in .nfo file format
########################################################################
print "Getting system information...\n" if $verbose;
system("$windir\\System32\\msinfo32.exe /nfo system.nfo");

########################################################################
#Get task list of running processes
########################################################################
print "Getting list of running processes...\n" if $verbose;
system ("$windir\\System32\\tasklist.exe > tasklist.txt");

########################################################################
#Get list of registered applications
########################################################################
print "Getting list of registered programs...\n" if $verbose;
system("$windir\\System32\\wbem\\WMIC.exe /output:ProgramList.txt product get name,version");

########################################################################
#Get list of running services
########################################################################
print "Getting list of running services...\n" if $verbose;
system("$windir\\System32\\sc.exe query type= service > services.txt");

########################################################################
#Get application and system event logs from the last 24 hours.
########################################################################
$ymday=&zero_pad($ymday);
$ymon=&zero_pad($ymon);
$hour=&zero_pad($hour);
$min=&zero_pad($min);
$sec=&zero_pad($sec);

print "Getting System event logs...\n" if $verbose;
system("$windir\\System32\\wevtutil.exe epl System /q:\"\*[System[TimeCreated[\@SystemTime>='${yyear}-${ymon}-${ymday}T${hour}:${min}:${sec}']]]\" System.evtx");
sleep 30;
print "Getting Application event logs...\n" if $verbose;
system("$windir\\System32\\wevtutil.exe epl Application /q:\"\*[System[TimeCreated[\@SystemTime>='${yyear}-${ymon}-${ymday}T${hour}:${min}:${sec}']]]\" Application.evtx");

########################################################################
#Get registry dumps.
########################################################################
#All
print "Getting 64bit Trend Micro Inc. registry key...\n" if $verbose;
system("$windir\\System32\\reg.exe export \"HKLM\\SOFTWARE\\Wow6432Node\\Trend Micro Inc.\" Reg03.reg");
print "Getting 32bit Trend Micro Inc. regisitry key...\n" if $verbose;
system("$windir\\System32\\reg.exe export \"HKLM\\SOFTWARE\\Trend Micro Inc.\" Reg04.reg");
print "Getting CurrentControlSet registry key...\n" if $verbose;
system("$windir\\System32\\reg.exe export \"HKLM\\SYSTEM\\CurrentControlSet\\services\" Reg05.reg");
print "Getting 32bit Trend Micro registry key...\n" if $verbose;
system("$windir\\System32\\reg.exe export \"HKLM\\SOFTWARE\\Trend Micro\" Reg-Trend_Micro_x86.reg");
print "Getting 64bit Trend Micro regisitry key...\n" if $verbose;
system("$windir\\System32\\reg.exe export \"HKLM\\SOFTWARE\\Wow6432Node\\Trend Micro\" Reg-Trend_Micro_x64.reg");
print "Getting 32bit TrendMicro regisitry key...\n" if $verbose;
system("$windir\\System32\\reg.exe export \"HKEY_LOCAL_MACHINE\\SOFTWARE\\TrendMicro\" Reg01.reg");
print "Getting 64bit TrendMicro regisitry key...\n" if $verbose;
system("$windir\\System32\\reg.exe export \"HKEY_LOCAL_MACHINE\\SOFTWARE\\Wow6432Node\\TrendMicro\" Reg02.reg");

print "Getting client and server install path...\n" if $verbose;
my ($local_path, $app_path, $svrname, $srsaddr)=&GetAppPath($nobit64);
chomp($local_path);
chomp($app_path);
chomp($svrname);
chomp($srsaddr);

if ( $app_path ne "" )
    {
    print "Getting client directory listing...\n" if $verbose;
    my $temppath=$app_path;
    $temppath =~ tr/\\/\\/s;
    system("dir /s/r \"$temppath\" > client\\dirlist.txt");
    }


if ( $local_path ne "" )
    {
    print "Getting server directory listing...\n" if $verbose;
    my $temppath=$local_path;
    $temppath =~ tr/\\/\\/s;
    system("dir /s/r \"$temppath\" > server\\dirlist.txt");
    }

########################################################################
#Get network information in .txt file format
########################################################################
print "Getting network information...\n" if $verbose;
system("$windir\\System32\\ipconfig.exe > ip_config.txt");
system("$windir\\System32\\netstat.exe -na> netstat-na.txt");
system("$windir\\System32\\TRACERT.EXE $svrname >> traceroute.txt");
system("$windir\\System32\\TRACERT.EXE $srsaddr >> traceroute.txt");

########################################################################
# Get client configuration data
########################################################################
print "Getting client configuration files...\n" if $verbose;
if ( $app_path ne "" )
    {
    copy("${app_path}ofcscan.ini","client/ofcscan.ini") || warn "WARNING: Could not copy ofcscan.ini: $!\n";
    copy("${app_path}ous.ini","client/ous.ini") || warn "WARNING: Could not copy ous.ini: $!\n";
    copy("${app_path}hotfix_history.ini","client/hotfix_history.ini") || warn "WARNING: Could not copy hotfix_history.ini: $!\n";
    copy("${app_path}ssnotify.ini","client/ssnotify.ini") || warn "WARNING: Could not copy ssnotify.ini: $!\n";

# get OSCE file version information 
&gg_GetFileVersion($app_path);

    }

########################################################################
# Get client log data.
########################################################################
print "Getting client log files...\n" if $verbose;
if ( -e "${windir}\\OFCNT.log" ) { copy("${windir}\\ofcnt.log","client/OFCNT.log") || warn "WARNING: Could not copy ofcnt.log: $!\n"; }
if ( -e "${tempdir}\\OFCNT.log" ) { copy ("${tempdir}\\ofcnt.log","client/OFCNT.log") || warn "WARNING: could not copy ofcnt.log: $!\n"; }
if ( -e "${sysdrive}\\TmPatch.log" ) { copy ("${sysdrive}\\TmPatch.log","client/TmPatch.log") || warn "WARNING could not copy TmPatch.log: $!\n"; }
if ( -e "${windir}\\setupapi.log" ) { copy("${windir}\\setupapi.log","client/setupapi.log") || warn "WARNING: Could not copy setupapi.log: $!\n"; }
if ( -e "${windir}\\inf\\setupapi.app.log" ) { copy("${windir}\\inf\\setupapi.app.log","client/setupapi.app.log") || warn "WARNING: Could not copy setupapi.app.log: $!\n"; }
if ( -e "${windir}\\inf\\setupapi.dev.log" ) { copy("${windir}\\inf\\setupapi.dev.log","client/setupapi.dev.log") || warn "WARNING: Could not copy setupapi.dev.log: $!\n"; }


# get upgrade logs.
opendir(DIRFH, "${app_path}Temp");
my @files = grep { /upgrade_/ } readdir(DIRFH);
closedir(DIRFH);
foreach my $file ( @files ) 
	{ chomp($file); copy ("${app_path}Temp\\${file}", "client/$file"); }

# get connection logs.
@files = &GetFileList($app_path, "ConnLog", "Conn_");
foreach my $file ( @files )
	{ copy ("${app_path}ConnLog\\${file}", "client/$file"); }

# get malware logs.
@files = &GetFileList($app_path, "Misc", ".log");
foreach my $file ( @files )
	{ copy ("${app_path}Misc\\${file}", "client/$file"); }

# get cleanup logs.
@files = &GetFileList($app_path, "report", ".log");
foreach my $file ( @files )
	{ copy ("${app_path}report\\${file}", "client/$file"); }
	
#get .db files
@files = &GetFileList($app_path, "Misc", ".db");
foreach my $file (@files)
    { copy ("${app_path}Misc\\${file}", "client/$file"); }
	
@files = &GetFileList($app_path, "Whitelist", ".db");
foreach my $file (@files)
    { copy ("${app_path}Whitelist\\${file}", "client/$file"); }
	
@files = &GetFileList($app_path, "", ".db");
foreach my $file (@files)
    { copy ("${app_path}\\${file}", "client/$file"); }

# get Application Control logs
@files = &GetFileList($app_path, "../iService/iAC", ".log");
foreach my $file (@files)
    { copy ("${app_path}\\${file}", "client/$file"); }

# get Application Control logs
@files = &GetFileList($app_path, "../iService/iAC/ac_logs", ".txt");
foreach my $file (@files)
    { copy ("${app_path}\\${file}", "client/$file"); }

# get Application Control database files 
@files = &GetFileList($app_path, "../iService/iAC/ac_data", ".db");
foreach my $file (@files)
    { copy ("${app_path}\\${file}", "client/$file"); }


if ( -e "${app_path}Misc\\scan_operation.csv" ) { copy ("${app_path}Misc\\scan_operation.csv", "client/scan_operation.csv") || warn "WARNING could not copy scan_operation.csv $!\n"; }
if ( -e "${app_path}AU_Data\\AU_Log\\TmuDump.txt" ) { copy ("${app_path}AU_Data\\AU_Log\\TmuDump.txt","client/TmuDump.txt") || warn "WARNING could not copy TmuDump.log: $!\n"; }
if ( -e "${app_path}OppLog\\OppLogs.log" ) { copy ("${app_path}OppLog\\OppLogs.log","client/OppLogs.log") || warn "WARNING could not copy OppsLogs.log: $!\n"; }
if ( -e "${app_path}somldbg.txt" ) { copy ("${app_path}somldbg.txt","client/somldbg.txt") || warn "WARNING could not copy somldbg.txt: $!\n"; }



########################################################################
# Get server configuration data.
########################################################################
if ( $local_path ne "" )
	{
	print "Getting server configuration files...\n" if $verbose;
	copy("${local_path}ofcscan.ini","server/ofcscan.ini") || warn "WARNING: Could not copy ofcscan.ini: $!\n";
	copy("${local_path}ous.ini","server/ous.ini") || warn "WARNING: Could not copy ous.ini: $!\n";
	copy("${local_path}Admin\\hotfix_history.ini","server/hotfix_history.ini") || warn "WARNING: Could not copy hotfix_history.ini: $!\n";
	copy("${local_path}Private\\ofcserver.ini","server/ofcserver.ini") || warn "WARNING: Could not copy ofcserver.ini: $!\n";
	copy("${local_path}Admin\\getserver.ini","server/getserver.ini") || warn "WARNING: Could not copy getserver.ini: $!\n";
	copy("${local_path}Admin\\ssnotify.ini","server/ssnotify.ini") || warn "WARNING: Could not copy ssnotify.ini: $!\n";
	copy("${local_path}CmAgent\\Product.ini","server/Product.ini") || warn "WARNING: Could not copy Product.ini: $!\n";
	copy("${local_path}CmAgent\\Agent.ini","server/Agent.ini") || warn "WARNING: Could not copy Agent.ini: $!\n";

########################################################################
# Get server logs data.
########################################################################
	print "Getting server log files...\n" if $verbose;
	copy("${sysdrive}/TMPatch.log", "server/TMPatch.log") || warn "WARNING: could not copy TMPatch.log: $!\n";
	copy("${windir}/OFCMAS.LOG", "server/OFCMAS.LOG") || warn "WARNING: could not copy OFCMAS.LOG: $!\n";
	copy("${local_path}Web\\Service\\AU_Data\\AU_Log\\TmuDump.txt","server/TmuDump.txt") || warn "WARNING: Could not copy TmuDump.txt: $!\n";
	copy("${local_path}LWCS\\access.log","server/LWCS_access.log") || warn "WARNING: Could not copy LWCS_access.log: $!\n";
	copy("${local_path}WSS\\access.log","server/WSS_access.log") || warn "WARNING: Could not copy WSS_access.log: $!\n";
	copy("${local_path}diagnostic.log","server/diagnostic.log") || warn "WARNING: Could not copy diagnostic.log: $!\n";
	copy("${local_path}LWCS\\diagnostic.log","server/LWCS_diagnostic.log") || warn "WARNING: Could not copy LWCS_diagnostic.log: $!\n";
	copy("${local_path}WSS\\diagnostic.log","server/WSS_diagnostic.log") || warn "WARNING: Could not copy WSS_diagnostic.log: $!\n";
	copy("${local_path}web\\Service\\diagnostic.log","server/web_Service_diagnostic.log") || warn "WARNING: Could not copy web_Service_diagnostic.log: $!\n";
	
	# Get IIS Logs from default location
	print "Get IIS Logs...\n" if $verbose;
	if ( -e $IISLogDir )
		{
		my @IISLogfiles = &gg_GetIISLogs($IISLogDir);
		foreach(@IISLogfiles) { copy("${IISLogDir}/$_", "server/IISLogs") || warn "WARNING: Could not copy $_ : $!\n"; }
		}	# end if IIS Log directory exists
	}	# end if local path is not null

########################################################################
# Get Edge server Configuration data.
########################################################################
	{ #start edge server configuration files
	print "Getting Edge Server configuration files...\n" if $verbose;
        my @filelist=("ofcedge.ini","ofcDdasvr.ini");
        my $edgecfg="";
        foreach $edgecfg (@filelist) 
            { 
            if ( -e "c:\\Program Files\\Trend Micro\\OfficeScan Edge Relay\\OfcEdgeSvc\\private\\$edgecfg" ) { copy("c:\\Program Files\\Trend Micro\\OfficeScan Edge Relay\\OfcEdgeSvc\\private\\$edgecfg","Edgesvr/$edgecfg") || warn "WARNING: Could not copy $edgecfg: $!\n"; } 
            }
	# get log files
	@filelist = ("OFCEDGE.Log", "OfcInstReg.log");
	foreach $edgecfg (@filelist)
	    { 
	    if ( -e "${windir}\\${edgecfg}" ) { copy("${windir}\\${edgecfg}", "Edgesvr/${edgecfg}" ) || warn "Could not open $edgecfg, $!\n" } 
	    }
        }  #end edge server configuration files

########################################################################
# Index collected files.
########################################################################
&getFileIndex();

########################################################################
# Compress data with password "trend" to .zip file
########################################################################
print "Compressing data...\n" if $verbose;
chdir "..";
system("\"${app_path}7z.exe\" a -ptrend -tzip ${fnprefix}.zip  $fnprefix");
exit 0;
}	#end MAIN:

sub GetAppPath
########################################################################
# GetAppPath, retreives the application and local path from the 
# registry infromation files.  The subroutine takes the nobit64 
# parameter to determine if the information provided is for 32 bit or
# 64 bit computer.  The program test encoding to properly open the file,
# being either ascii or UTF-16.
########################################################################
{


local ($nobit64)=@_;
local ($app_path, $local_path, $infile, $svrname, $srsaddr)=("","","","","");
local $record;
local $INFH;
local $encoding="";

#REGEDIT4  == plain text
#Windows Registry Editor Version 5.00 == UTF-16 encoding (returns 0 if found 256 if not found)

############################################################
# Decide which registry file to read.  For 64bit systems
# read Reg02.reg.  For 32bit system then read Reg01.reg.
############################################################
if ( $nobit64 == 1 )
	{ $infile = "Reg02.reg"; }
else
	{ $infile = "Reg01.reg"; }

############################################################
# Determine the encoding type.  On 32bit systems the .reg 
# file was just plain ASCII but from 64bit operating 
# systems the .reg file is UTF-16 encoded.
############################################################
open($INFH,"$infile");
binmode($INFH);
if(read($INFH,my $filestart, 500)) 
    {
    $encoding = guess_encoding($filestart);
    if(ref($encoding)) { $encoding=($encoding->name);}
	else { $encoding=""; }
    }
close($INFH);

# print "$encoding\n";
#ascii
#UTF-16

############################################################
# open the file up in either ascii or UTF-16 depending on
# the encoding type.
############################################################
if ( $encoding eq "ascii" )
	{ open ($INFH, "$infile"); }	#end if file encoding is ascii
elsif ( $encoding eq "UTF-16" )
	{ open( $INFH, "<:encoding(UTF-16)", $infile); }	#End elsif file encoding is UTF-16
else 	{ return ""; }	#else I do not know file encoding


############################################################
# Open the registry file and search for Local_Path, the
# path to the server install, and serch for Application
# Path, the location of the client applction install.
############################################################
while ( $record=<$INFH> )
	{
	if ( $record =~ /^\"Local_Path\".*/ ) 
		{ 
		my @stuff=split(/"\s*/, $record);
		#$stuff[3]=~s/\\\\/\\/g;
		$local_path=$stuff[3];
		}	#end if record is server directory
	if ( $record =~ /^\"Application Path\".*/) 
		{
		my @stuff=split(/"\s*/, $record);
		#$stuff[3]=~s/\\\\/\\/g;
		$app_path=$stuff[3];

		}	#end if record is client directory
	
        if ( $record =~ /^\"Server\".*/ && $svrname eq "" ) 
		{
		my @stuff=split(/"\s*/, $record);
		$svrname=$stuff[3];
		}	#end if record is server name
	
        if ( $record =~ /^\"LocalScanServerAddress\".*/ ) 
		{
		my @stuff=split(/"\s*/, $record);
		$srsaddr=$stuff[3];
		}	#end if record is SRS server name
	}	#end while not end of file $INFH

close $INFH;

return($local_path, $app_path, $svrname, $srsaddr);

# Reg02.reg -- server install path
# "Local_Path"="c:\\program files (x86)\\Trend..."
# Reg02.reg -- client install path
# "Application Path"="c:\\program files..."

}	#end sub GetAppPath

sub GetFileList
############################################################
# Get a list of files matching a specified criteria
############################################################
{
($app_path, $file_path, $filestring)=@_;

opendir(DIRFH, "${app_path}$file_path");
my @files = grep { /$filestring/ } readdir(DIRFH);
closedir(DIRFH);
return(@files);
}	#end sub GetFileList

sub gg_GetFileVersion
############################################################
# Get file version information for specific OSCE binaries
############################################################
{
my ($dirname) = @_;
my @filename = ("TmListen.exe","TmListen_64x.dll","pccntmon.exe","upgrade.exe","tmbmsrv.exe","ntrtscan.exe","ccsf/tmccsf.exe","vsapi64.dll","vsapi32.dll","BM/tmbmsvr.exe","tmproxy.exe","tmpfw.exe","pccntupd.exe","cntaosmgr.exe","ntrmv.exe","ofcpfwsvc.exe","tsc.exe","tsc64.exe","patch.exe","patch64.exe","vsencode.exe","wolfielauncher.exe","ofcedgesvc/web/service/OfcEdgeSvc.exe","ofcedgesvc/web/service/ofcddasvr.exe","flowcontrol.dll","flowcontrol_64x.dll","libcntprodres.dll","libcntprodres_64x.dll","ofcpipc.dll","ofcpipc_64x.dll","ofcpluginapi.dll","ofcpluginapi_64x.dll","perficrcperfmonmgr.dll","perficrcperfmonmgr_64x.dll","timestring.dll","timestrind_64x.dll","libnetctrl.dll","libnetctrl_64x.dll","libtmcav.dll","libtmcav_64x.dll","loadhttp.dll","loadhttp_64x.dll","ofcpwfcommon.dll","ofcpwfcommon_64x.dll","pccwfwmo.dll","pccwfwmo_64x.dll","tmlistenshare.dll","tmlistenshare_64x.dll","tmpac.dll","tmpac_64x.dll","tmsock.dll","tmsock_64x.dll","sqlite3.dll","ClientHelp/showmsg.exe");
my $ptrFilename = "";
my $version_info = "";
my $outfile = "client/FileVersion.txt";

open (my $OFILE, ">", $outfile) || warn "Could not open $outfile for write, $!\n";

for (my $i=0; $i <= $#filename; $i++)
    {
    my $fname=$dirname.$filename[$i];
    if ( -e $fname )
        {
        $ptrFilename = Win32::Exe->new($fname);
        $version_info = $ptrFilename->get_version_info();
        my @x = split(/\n/, Dumper($version_info));
        my @y = grep(/FileVersion/, @x);
        print $OFILE "$fname:\t";
        print $OFILE "@y\n";
        }	#end if file name exists
    else { print $OFILE "$fname not found.\n"; }
    }		#end for i=0 to # elements in @filename array
close($OFILE);
return(0);
}	#end GETFILEVERSION routine.

sub gg_GetIISLogs
############################################################
# Get the last 10 log files from the default IIS location
############################################################
{
my ($IISLogs)=@_;
my @filelist;
my @IISLogfiles;
my $DIR;


opendir($DIR, $IISLogs) || warn "Warning: Could not open $IISLogs, $!\n";
@filelist = grep(!/^(\.|\.\.)$/, readdir($DIR));
closedir($DIR);

for ( my $i=$#filelist; ($i > $#filelist-10 && $i >= 0); $i--)
    { push @IISLogfiles, $filelist[$i]; }

return(@IISLogfiles);

}	#end gg_GetIISLogs

sub getFileIndex
############################################################
# Get file index information for specific OSCE binaries
############################################################
{
use Cwd;
use Digest::SHA qw(sha256_hex);

my @filelist;
my ($filename, $findexname) = ("", "FileIndexList.txt");
my @dirlist = (".", "client","server","server/IISLogs","Edgesvr");
my $dirname;
my ($DIRH, $FINH);
my $currentdir = getdcwd();
my $sha2 = Digest::SHA->new(256);	

open ($FINH, ">", $findexname) || warn "Could not open $findexname for write, $!\n";
print $FINH "This file contains the SHA2 hash values and file name of the files collected.\n";
print $FINH "Current Location: $currentdir\n";
foreach $dirname ( @dirlist )
    {
    opendir $DIRH, "$dirname";
    print $FINH "\nDIRECTORY NAME: $dirname\n";
    @filelist = grep { $_ ne '.' && $_ ne '..' } readdir $DIRH;
    closedir $DIRH;
    foreach $filename ( @filelist ) 
	{
	if ( -f "$dirname/$filename" )
	    {
    	    open(my $FH, "$dirname/$filename") || warn "Cannot open $dirname/$filename $!\n";
	    binmode($FH);
	    my $sha2sum = $sha2->addfile(*$FH)->hexdigest;
	    close $FH; 
	    print $FINH "$sha2sum : $filename\n"; 
	    }	#end check for file type
	}	#end foreach $filename loop

    }	#end foreach directory name loop.
close $FINH;
}	#end getFileIndex subroutine.
