Author : "G D Geen"
DateWritten : "19 Aug 2015"
DateUpdated : "19 Feb 2016"
DateUpdated : "18 May 2016"
DateUpdated : "17 Jun 2016"
Version 1.3

COLLECTED INFORMATION
=====================
The program collects operating system information and OfficeScan client and server
related log files and configuration files.  What we collect:

Application and System evnet logs
=================================
* Application.evtx
* System.evtx

Operating Environmnet
=====================
* ProgramList.txt -- List of registered programs
* services.txt    -- List of running services
* system.nfo      -- System Information
* tasklist.txt    -- List of running tasks/programs

Registry
=========
* Reg01.reg -- Dump of TrendMicro registry hive
* Reg02.reg -- Dump of TrendMicro registry hive (64bit)
* Reg03.reg -- Dump of Trend Micro Inc. registry have (64bit)
* Reg04.reg -- Dump of Trend Micro Inc. registry hive (32bit)
* Reg05.reg -- Dump of CurrentControlSet\Serivces registry hive

Network Config
==============
* ip_config.txt   -- IP Address configuration
* netstat-na.txt  -- Network connections/ports in use
* traceroute.txt  -- Network route from this computer to the OSCE and the SRS server

At no time do we modify any regitry keys to enable or disable any services. This
program collects existing information only.  For more detailed debug log collection
please use our CaseDiagnosticTool; http://downloadcenter.trendmicro.com

OfficeScan Information
======================
Client
------
A collection of OfficeScan Agent logs and configuration files used for
analysis during debug operations.

* dirlist.txt -- a recursive directory listing of the client directory
* FileVersion.txt -- Version information of selected OSCE client binary files.

Server
------
A collection of OfficeScan Server logs and configuration files use for
analysis during debug operations.

UPDATE INFORMATION
==================
22 Oct 2015 - change capture of operating system event logs from 1 day to 7 days.
 7 Nov 2015 - Change compression type to .zip
13 Nov 2015 - Added client and server side ssnotify.ini file
            - Added ipconfig command to .txt file
            - Added netstat -na command to .txt file
 7 Dec 2015 - Added HKLM\SYSTEM\CurrentControlSet\services as Reg05.reg
15 Dec 2015 - Added Product.ini file for TMCM connectivity information
            - Some commands were executed from the hardcoded windows path rather than
              relying on the environment variables to determin the windows install path.
18 Dec 2015 - Add password, trend, to zip file.
27 Jan 2016 - Add Agent.ini to collect TMCM configuration information for the OSCE server.
19 Feb 2016 - Add scan_operation logs, and malware detection logs: AEGIS_BM, CCCACIn, NCIE, pccnt32, spyware.
18 May 2016 - Add recursive directory listing of client and server directories if they exist.
              Add trace route from client to server.
16 Jun 2016 - Add sendmail scan log -- somldbg.txt, cleanup logs -- reports/*.log
            - Add file version infomraiton for selected OSCE binaries