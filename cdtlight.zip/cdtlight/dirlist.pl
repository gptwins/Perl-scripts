my $app_path="C:\\program files (x86)\\trend micro\\officescan client\\";

print "$app_path\n";
system("dir /s/r \"$app_path\" ");
exit(0);