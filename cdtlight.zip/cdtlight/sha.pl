MIAN:
{
use strict;
use warnings;
use Digest::SHA;

my $sha = Digest::SHA->new("sha256");
my $filename = shift || $0;
my $digest;

$sha->addfile($filename);
$digest = $sha->hexdigest;

print "$digest : $filename\n";

}