MAIN:
{
use strict;
use warnings;
use Digest::MD5;

my $filename;
my $fh;			#file handle
my $md5;

# read the file name from the command line or use current filename
$filename = shift || $0;
open($fh, "<", $filename) || die "ERROR: Could not open file $filename, $!\n";
binmode($fh);

$md5 = Digest::MD5->new;
while (<$fh>)
	{ $md5->add($_); }
close($fh);
print $md5->hexdigest," : $filename\n";
exit(0);
}	#end MAIN