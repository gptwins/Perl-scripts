MAIN:
{
&getFileIndex;
}

sub getFileIndex
############################################################
# Get file index information for specific OSCE binaries
############################################################
{
use Cwd;
use Digest::SHA qw(sha256_hex);

my @filelist;
my ($filename, $findexname) = ("", "FileIndexList.txt");
# my @dirlist = (".", "client","server","Edgesvr");
my @dirlist = (".");
my $dirname;
my ($DIRH, $FINH);
my $currentdir = getdcwd();
my $sha2 = Digest::SHA->new(256);	# create a new SHA256 object

open ($FINH, ">", $findexname) || warn "Could not open $findexname for write, $!\n";
print $FINH "This file contains the SHA2 hash values and file name of the files collected.\n";
print $FINH "Current Location: $currentdir\n";
foreach $dirname ( @dirlist )
    {
    opendir $DIRH, "$dirname";
    print $FINH "\nDIRECTORY NAME: $dirname\n";
    @filelist = grep { $_ ne '.' && $_ ne '..' } readdir $DIRH;
    closedir $DIRH;
    foreach $filename ( @filelist ) 
	{
	if ( -f "$dirname/$filename" )
	    {
    	    open(my $FH, "$dirname/$filename") || warn "Cannot open $dirname/$filename $!\n";
	    binmode($FH);
	    my $sha2sum = $sha2->addfile(*$FH)->hexdigest;
	    close $FH; 
	    print $FINH "$sha2sum : $filename\n"; 
	    }	#end check for file type
	}	#end foreach $filename loop

    }	#end foreach directory name loop.
close $FINH;
}	#end getFileIndex subroutine.