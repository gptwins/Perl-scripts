use strict;
use warnings;
use File::Copy;

MAIN:
{
my $IISLogDir="C:\\inetpub\\logs\\LogFiles\\W3SVC3";
# Get IIS Logs from default location
print "get IIS Logs procedure call...\n";
print "$IISLogDir\n";
my @IISLogfiles = &gg_GetIISLogs($IISLogDir);
foreach(@IISLogfiles) { copy("${IISLogDir}/$_", "C:\\TEMP") || warn "WARNING: Could not copy $_ : $!\n"; }

}


sub gg_GetIISLogs
############################################################
# Get the last 10 log files from the default IIS location
############################################################
{
my ($IISLogs)=@_;
my @filelist;
my @IISLogfiles;
my $DIR;


opendir($DIR, $IISLogs) || warn "Warning: Could not open $IISLogs, $!\n";
@filelist = grep(!/^(\.|\.\.)$/, readdir($DIR));
closedir($DIR);

for ( my $i=$#filelist; ($i > $#filelist-10 && $i >= 0); $i--)
    { push @IISLogfiles, $filelist[$i]; }

return(@IISLogfiles);

}	#end gg_GetIISLogs