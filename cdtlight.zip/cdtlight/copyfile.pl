MAIN:
{
use strict;
use warnings;
use File::Copy;

my ($progfilesx86,$programfiles,$nobit64,$sysroot,$sysdrive,$windir,$computername)=("","",0,"","","","");
########################################################################
##Get environment variables
#########################################################################
$programfiles="$ENV{ProgramFiles}";
if ( $ENV{'ProgramFiles(x86)'} ) 
    { $progfilesx86="$ENV{'ProgramFiles(x86)'}"; 
	$nobit64=1; 
    }
else { $nobit64=0; }
$sysroot="$ENV{SystemRoot}";
$sysdrive="$ENV{SystemDrive}";
$windir="$ENV{windir}";
$computername="$ENV{COMPUTERNAME}";

# print" $windir $sysroot $sysdrive $windir $computername\n";

#copy ("${windir}\\ofcnt.log", "ofcnt.log");
#copy("c:\\program files (x86)\\trend micro\\officescan client\\ofcscan.ini", "ofcscan.ini") || warn "help me! $!\n";

my $app_path="c:\\Program Files (x86)\\Trend Micro\\Officescan Client\\";

my @filelist = &GetFileList($app_path, $file_path, $filestring);
foreach my $file (@filelist)
	{ print $file; }

} 	#end main


sub GetFileList
############################################################
Get a list of files matching a specified critia
############################################################
{
($app_path, $file_path, $filestring)=@_;

opendir(DIRFH, "${app_path}$file_path");
my @files = grep { /$filestring/ } readdir(DIRFH);
closedir(DIRFH);
return(@files);
}	#end sub GetFileList